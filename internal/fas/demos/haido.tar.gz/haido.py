#!/usr/bin/env python3
"""Haido: A game of ridiculous deduction - command line edition"""

import json
import random
import sys
from pathlib import Path

STATE_FILE = Path("haido_state.json")

SUSPECTS = [
    "Professor Porkington",
    "Lady Biscuitworth",
    "Colonel Sneaky",
    "Dr. Wigglesworth",
    "Miss Crumpet",
    "Baron Von Suspicious"
]

ROOMS = [
    "The Library of Lies",
    "The Kitchen of Chaos",
    "The Ballroom of Backstabs",
    "The Study of Secrets",
    "The Conservatory of Crimes",
    "The Dining Hall of Deceit"
]

WEAPONS = [
    "a wet kipper",
    "a rubber chicken",
    "a pool noodle",
    "a wooden spoon",
    "a rolled-up newspaper",
    "a peculiar turnip"
]

def normalize_name(name, category):
    """Match user input to canonical name."""
    name_lower = name.lower().strip()

    if category == "suspect":
        options = SUSPECTS
    elif category == "room":
        options = ROOMS
    else:  # weapon
        options = WEAPONS

    # Exact match
    for opt in options:
        if opt.lower() == name_lower:
            return opt

    # Partial match (first word)
    for opt in options:
        if opt.lower().startswith(name_lower):
            return opt

    # Partial match (any word)
    for opt in options:
        if name_lower in opt.lower():
            return opt

    return None

def load_state():
    """Load game state from file."""
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return None

def save_state(state):
    """Save game state to file."""
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)

def new_game():
    """Start a new game."""
    state = {
        "culprit": random.choice(SUSPECTS),
        "location": random.choice(ROOMS),
        "weapon": random.choice(WEAPONS),
        "guesses": [],
        "max_guesses": 10,
        "game_won": False,
        "game_over": False
    }
    save_state(state)
    print("🎮 A new mystery awaits!")
    print("   Use 'suggest' to gather clues or 'accuse' to solve the crime.")
    print(f"   You have {state['max_guesses']} total guesses to crack the case.\n")
    print("Type 'haido.py --help' for command options.")
    return 0

def evaluate_guess(state, suspect, room, weapon):
    """Count how many elements match the solution."""
    correct = sum([
        suspect == state["culprit"],
        room == state["location"],
        weapon == state["weapon"]
    ])
    return correct

def suggest(state, suspect, room, weapon):
    """Make a suggestion and get feedback."""
    if state["game_over"]:
        print("❌ Game is already over!")
        return 0

    correct = evaluate_guess(state, suspect, room, weapon)

    state["guesses"].append({
        "suspect": suspect,
        "room": room,
        "weapon": weapon,
        "correct": correct,
        "type": "suggest"
    })
    save_state(state)

    # Cluedo-style feedback
    if correct == 3:
        print("✓ All three elements match! But to win, you must accuse.")
    elif correct == 2:
        print("✓ Two of those are correct! You're getting warm...")
    elif correct == 1:
        print("~ Only one element is correct.")
    else:
        print("✗ None of those are right. Keep investigating!")

    print(f"   Guesses used: {len(state['guesses'])}/{state['max_guesses']}\n")
    return 0

def accuse(state, suspect, room, weapon):
    """Make an accusation. Win or lose!"""
    if state["game_over"]:
        print("❌ Game is already over!")
        return 0

    if len(state["guesses"]) >= state["max_guesses"]:
        print("❌ No accusations left! Game over.")
        state["game_over"] = True
        save_state(state)
        return 0

    correct = evaluate_guess(state, suspect, room, weapon)

    state["guesses"].append({
        "suspect": suspect,
        "room": room,
        "weapon": weapon,
        "correct": correct,
        "type": "accuse"
    })

    if correct == 3:
        state["game_won"] = True
        state["game_over"] = True
        save_state(state)

        print("🎉 BRILLIANT DEDUCTION!")
        print(f"   The culprit: {suspect}")
        print(f"   The location: {room}")
        print(f"   The weapon: {weapon}")
        print(f"\n   Solved in {len(state['guesses'])} {'guess' if len(state['guesses']) == 1 else 'guesses'}!\n")
        return 0
    else:
        state["game_over"] = True
        save_state(state)

        print("💀 WRONG! The case goes cold...")
        print(f"   The actual culprit: {state['culprit']}")
        print(f"   The actual location: {state['location']}")
        print(f"   The actual weapon: {state['weapon']}\n")
        return 0

def status(state):
    """Show current game state."""
    if state["game_won"]:
        print("✨ CASE SOLVED!")
    elif state["game_over"]:
        print("💀 CASE CLOSED (Unsolved)")
    else:
        print(f"🔍 INVESTIGATION IN PROGRESS")

    print(f"   Guesses used: {len(state['guesses'])}/{state['max_guesses']}\n")

    if state["guesses"]:
        print("   History:")
        for i, guess in enumerate(state["guesses"], 1):
            icon = "✓" if guess["type"] == "accuse" and guess["correct"] == 3 else "~"
            print(f"   {i}. [{guess['type'].upper()}] {guess['correct']}/3 correct")
            print(f"      • {guess['suspect']}")
            print(f"      • {guess['room']}")
            print(f"      • {guess['weapon']}")

    if not state["game_over"]:
        print("\n   Available suspects:")
        for s in SUSPECTS:
            print(f"      • {s}")
        print("\n   Available rooms:")
        for r in ROOMS:
            print(f"      • {r}")
        print("\n   Available weapons:")
        for w in WEAPONS:
            print(f"      • {w}")

    print()
    return 0

def show_help():
    """Show help message."""
    print("HAIDO - A Game of Ridiculous Deduction\n")
    print("Commands:")
    print("  haido.py new                    - Start a new game")
    print("  haido.py status                 - Show current game state")
    print("  haido.py suggest A B C          - Make a suggestion (A=suspect, B=room, C=weapon)")
    print("  haido.py accuse A B C           - Make an accusation (A=suspect, B=room, C=weapon)")
    print("  haido.py --help                 - Show this message\n")
    print("Examples:")
    print("  haido.py suggest 'Professor Porkington' 'The Library' 'a wet kipper'")
    print("  haido.py accuse porkington library kipper\n")
    return 0

def main():
    if len(sys.argv) < 2:
        show_help()
        return 0

    command = sys.argv[1].lower()

    if command == "--help" or command == "-h":
        show_help()
        return 0

    if command == "new":
        return new_game()

    state = load_state()
    if state is None and command != "new":
        print("❌ No game in progress. Start with: haido.py new\n")
        return 0

    if command == "status":
        return status(state)

    if command in ("suggest", "accuse"):
        if len(sys.argv) != 5:
            print(f"❌ Usage: haido.py {command} <suspect> <room> <weapon>\n")
            return 0

        suspect_input = sys.argv[2]
        room_input = sys.argv[3]
        weapon_input = sys.argv[4]

        suspect = normalize_name(suspect_input, "suspect")
        room = normalize_name(room_input, "room")
        weapon = normalize_name(weapon_input, "weapon")

        if not suspect or not room or not weapon:
            print("❌ Invalid input. Could not match:")
            if not suspect:
                print(f"   Suspect: '{suspect_input}'")
            if not room:
                print(f"   Room: '{room_input}'")
            if not weapon:
                print(f"   Weapon: '{weapon_input}'")
            print()
            return 0

        if command == "suggest":
            return suggest(state, suspect, room, weapon)
        else:
            return accuse(state, suspect, room, weapon)

    print(f"❌ Unknown command: {command}\n")
    show_help()
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(f"❌ Error: {e}\n")
        sys.exit(0)
