# Haido: A Game of Ridiculous Deduction

A daft command-line Cluedo-style deduction game where you solve a silly crime at a posh Scottish manor.

Someone has committed a heinous and ridiculous crime — your job is to figure out **who**, **where**, and **what they used** before your investigation runs cold.

## How to Play

You have **10 total guesses** to solve the mystery. Each guess can be either a **suggestion** (gather clues) or an **accusation** (attempt to solve).

### Commands

**Start a new game:**
```bash
python3 haido.py new
```

**Make a suggestion** (get feedback on how close you are):
```bash
python3 haido.py suggest <suspect> <room> <weapon>
```

**Make an accusation** (try to solve the crime):
```bash
python3 haido.py accuse <suspect> <room> <weapon>
```

**Check your progress:**
```bash
python3 haido.py status
```

**View help:**
```bash
python3 haido.py --help
```

## Game Rules

- Each suggestion tells you how many of your three guesses are correct (0/3, 1/3, 2/3, or 3/3)
- You need all three correct to win — an accusation with 3/3 solves the case immediately
- If your accusation is wrong, the investigation ends and the culprit escapes
- Game state is saved to `haido_state.json` so you can play multiple guesses in sequence

## Names & Matching

The game is smart about names — it'll match partial input:

```bash
# These all work:
python3 haido.py suggest "Professor Porkington" "The Library of Lies" "a wet kipper"
python3 haido.py suggest porkington library kipper
python3 haido.py suggest prof lib kipper
python3 haido.py suggest "prof" "ballroom" "noodle"
```

## The Cast

**Suspects:**
- Professor Porkington
- Lady Biscuitworth
- Colonel Sneaky
- Dr. Wigglesworth
- Miss Crumpet
- Baron Von Suspicious

**Rooms:**
- The Library of Lies
- The Kitchen of Chaos
- The Ballroom of Backstabs
- The Study of Secrets
- The Conservatory of Crimes
- The Dining Hall of Deceit

**Weapons:**
- a wet kipper
- a rubber chicken
- a pool noodle
- a wooden spoon
- a rolled-up newspaper
- a peculiar turnip

## Example Game

```bash
$ python3 haido.py new
🎮 A new mystery awaits!
   Use 'suggest' to gather clues or 'accuse' to solve the crime.
   You have 10 total guesses to crack the case.

$ python3 haido.py suggest prof kitchen spoon
✗ None of those are right. Keep investigating!
   Guesses used: 1/10

$ python3 haido.py suggest colonel ballroom chicken
~ Only one element is correct.
   Guesses used: 2/10

$ python3 haido.py status
🔍 INVESTIGATION IN PROGRESS
   Guesses used: 2/10
   [history shown...]

$ python3 haido.py accuse baron study turnip
🎉 BRILLIANT DEDUCTION!
   The culprit: Baron Von Suspicious
   The location: The Study of Secrets
   The weapon: a peculiar turnip

   Solved in 3 guesses!
```

## Requirements

Python 3.6+ with only the standard library (no external dependencies).
